// Define variables
let monthlyBudget = 0;
let expenses = [];

// Function to add monthly budget
function addBudget() {
    const budgetInput = document.getElementById('budgetInput');
    const budgetValue = parseFloat(budgetInput.value);

    if (isNaN(budgetValue) || budgetValue <= 0) {
        alert('Please enter a valid monthly budget.');
        return;
    }else{
         monthlyBudget = budgetValue;
    budgetInput.value = '';
    }

   

    updateRemainingBudget();
}

// Function to add an expense
function addExpense() {
    const descriptionInput = document.getElementById('descriptionInput');
    const amountInput = document.getElementById('amountInput');
    const dateInput = document.getElementById('dateInput');

    const description = descriptionInput.value.trim();
    const amount = parseFloat(amountInput.value);
    const date = dateInput.value;

    if (description === '' || isNaN(amount) || amount <= 0 || date === '') {
        alert('Please enter valid expense details.');
        return;
    }

    const expense = {
        description,
        amount,
        date
    };

    expenses.push(expense);

    descriptionInput.value = '';
    amountInput.value = '';
    dateInput.value = '';

    updateExpenseTable();
    updateRemainingBudget();
}

// Function to update the expense table
function updateExpenseTable() {
    const tableBody = document.getElementById('expenseTableBody');
    tableBody.innerHTML = '';

    expenses.forEach(expense => {
        const row = document.createElement('tr');

        const descriptionCell = document.createElement('td');
        descriptionCell.textContent = expense.description;
        row.appendChild(descriptionCell);

        const amountCell = document.createElement('td');
        amountCell.textContent = expense.amount.toFixed(2);
        row.appendChild(amountCell);

        const dateCell = document.createElement('td');
        dateCell.textContent = expense.date;
        row.appendChild(dateCell);

        tableBody.appendChild(row);
    });
}

// Function to update the remaining budget
function updateRemainingBudget() {
    const remainingBudgetValue = document.getElementById('remainingBudgetValue');
    const totalExpense = expenses.reduce((total, expense) => total + expense.amount, 0);
    const remainingBudget = monthlyBudget - totalExpense;
    remainingBudgetValue.textContent = remainingBudget.toFixed(2);
}
